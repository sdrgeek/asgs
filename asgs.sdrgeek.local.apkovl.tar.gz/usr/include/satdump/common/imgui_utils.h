#pragma once

void ImGuiUtils_BringCurrentWindowToFront();
void ImGuiUtils_SendCurrentWindowToBack();