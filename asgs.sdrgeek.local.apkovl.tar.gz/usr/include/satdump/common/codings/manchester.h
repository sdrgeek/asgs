#pragma once
#include <cstdint>

// G. E. Thomas Manchester decoder
int manchesterDecoder(uint8_t *in, int length, uint8_t *out);