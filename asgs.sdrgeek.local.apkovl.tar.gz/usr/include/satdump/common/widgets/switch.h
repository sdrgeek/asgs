#pragma once

void ToggleButton(const char *str_id, int *v);
void FancySlider(const char *str_id, const char *label, float *v, int width);
