#pragma once
#include <string>

template <typename T>
std::string format_notated(T value, std::string units = "");
