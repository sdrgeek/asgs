Those files, used to generate false color imagery from HRIT processed ABI data were made by Harry Dove-Robinson. The original LUT and correction curve can be found at https://github.com/hdoverobinson/wx-star_false-color or at https://wx-star.com/post/169608535305/designing-false-colors-for-goes-r-hrit. 
Thanks for letting me use them in SatDump!
