# ZA

This enhancement, also called *General IR enhancement*, uses a look-up table to increase contrast by saturating the low and high temperature regions where is typically very little information.

### Appearance

Gray scale.

![ZA](lut/cal/WXtoImg-ZA.png)

### Intended usage

Meteorology.

### Limitations

No specific limitatiton.