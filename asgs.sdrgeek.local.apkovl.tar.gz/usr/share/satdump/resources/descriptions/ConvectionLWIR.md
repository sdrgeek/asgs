# Color convection longwave IR

This enhancement uses a look-up table to better make convective phenomena stand out, such as cumulonimbus clouds.

### Appearance

Color scale.

![LWIR](lut/cal/ConvectionLWIR.png)

### Intended usage

Meteorology.

### Limitations

Experimental.