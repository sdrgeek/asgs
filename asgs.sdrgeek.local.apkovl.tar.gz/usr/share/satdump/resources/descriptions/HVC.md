# HVC

This enhancement makes use of the HVC color model. The brightness is selected from the visible channels (either number 2 or 1), and the channel 4 temperature to select the hue. 

### Appearance

The HVC colour model attempts to ensure that different colours at the same value will appear to the eye to be the same brightness and the spacing between colours representing each
degree will appear to the eye to be similar. 

### Intended usage

General APT imagery.

### Limitations

No specific limitations.