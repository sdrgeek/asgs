# Mid Level Water Vapor

This enhancement uses the water vapor absorption wavelength at 4.56 µm to detect water vapor in the middle part of the atmosphere. A color temperature scale-like enhancement is then used to enable easier analysis.

### Appearance

Low water vapor content shows as blue, as the quantity increases the color turns to yellow and red.

### Intended usage

Meteorology.

### Limitations

No specific limitation.